# JEMIMAS-ASKING

Two-player, two-device quiz with live perceived scores, endgame reveal, and a Big-Question twist.

## Dev

```bash
npm i
npm run dev
Open your browser at [http://localhost:5173](http://localhost:5173)