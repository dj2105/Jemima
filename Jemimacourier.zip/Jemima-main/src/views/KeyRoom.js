// /src/views/KeyRoom.js
// Host setup screen with inverted dark-blue theme (white on dark).

import { initFirebase, ensureAuth, db, doc, setDoc, getDoc, auth } from '../lib/firebase.js';
import watchRoom from '../roomWatcher.js';

export default function KeyRoom(ctx = {}) {
  const el = document.createElement('section');
  el.className = 'wrap';
  const $ = (s) => el.querySelector(s);

  // ---------- LS helpers ----------
  const LS = {
    get(k, d = '') { try { return localStorage.getItem(k) ?? d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch {} },
    hasKey() { return !!(LS.get('gemini_api_key','').trim()); }
  };

  // ---------- Code helpers ----------
  const ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ123456789'; // no O/0
  const genCode = (n = 3) => Array.from({ length: n }, () => ABC[Math.floor(Math.random() * ABC.length)]).join('');
  const getCode = () => (LS.get('lastGameCode','') || '').toUpperCase();

  // ---------- Lights ----------
  function setLight(id, state) {
    const colors = { red:'#ff2a87', amber:'#ffcc00', green:'#18ea4a' };
    const dot = $(id);
    if (dot) dot.style.background = colors[state] || colors.red;
  }
  function allGreen() {
    return $('#light-api').dataset.state==='green'
        && $('#light-q').dataset.state==='green'
        && $('#light-j').dataset.state==='green'
        && getCode().length===3;
  }
  function light(id, state) {
    const n = $(id);
    if (!n) return;
    n.dataset.state = state;
    setLight(id, state);
    updateSeedButton();
  }
  function updateSeedButton(){
    $('#seed').disabled = !allGreen();
    $('#seedHelp').textContent = $('#seed').disabled ? 'Make all lights green for this CODE.' : '';
  }

  // ---------- Firestore IO ----------
  async function readPromptsForCode(code) {
    if (!code) return { hasQ:false, hasJ:false, q:'', j:'' };
    await initFirebase(); await ensureAuth();
    const q = await getDoc(doc(db,'rooms',code,'seed','qcfg')).catch(()=>null);
    const j = await getDoc(doc(db,'rooms',code,'seed','jmaths')).catch(()=>null);
    const qPrompt = q?.data()?.spec?.prompt || '';
    const jPrompt = j?.data()?.spec?.prompt || '';
    return { hasQ: !!qPrompt, hasJ: !!jPrompt, q: qPrompt, j: jPrompt };
  }

  async function savePrompt(kind) {
    const code = getCode();
    if (!code) return flash('GET CODE FIRST');
    await initFirebase(); await ensureAuth();
    const raw = (kind==='q' ? $('#q').value : $('#j').value).trim();
    if (!raw) return flash('PASTE FIRST');
    const id  = (kind==='q' ? 'qcfg' : 'jmaths');
    await setDoc(doc(db,'rooms',code,'seed',id), { spec:{ prompt: raw } }, { merge:true });
    light(kind==='q' ? '#light-q' : '#light-j', 'green');
    flash('SAVED');
  }

  async function saveApi() {
    const v = $('#api').value.trim();
    if (!v || v==='••••••••') return;
    LS.set('gemini_api_key', v);
    $('#api').value = '••••••••';
    light('#light-api','green');
    flash('KEY SAVED');
  }

  async function createCode() {
    await initFirebase(); await ensureAuth();
    const code = genCode(3);
    LS.set('lastGameCode', code);
    LS.set('playerRole', 'host');
    $('#big').textContent = code;

    await setDoc(doc(db,'rooms',code), {
      meta:{ hostUid: auth.currentUser?.uid || 'anon' },
      state:'lobby'
    }, { merge:true });

    try { await watchRoom(code); } catch {}

    light('#light-q','red');
    light('#light-j','red');

    const { hasQ, hasJ, q, j } = await readPromptsForCode(code);
    if (hasQ) { $('#q').value = q; light('#light-q','green'); }
    if (hasJ) { $('#j').value = j; light('#light-j','green'); }
  }

  function toSeeding() {
    if (!allGreen()) return;
    location.hash = '#/seeding';
  }

  function flash(msg){
    const n=$('#status'); n.textContent=msg;
    clearTimeout(flash._t); flash._t=setTimeout(()=> n.textContent='',1500);
  }

  // ---------- UI ----------
  el.innerHTML = `
    <style>
      :root { --dark-blue:#020b1a; }
      body { background:var(--dark-blue); color:#fff; }
      .panel{ background:var(--dark-blue); color:#fff; border:2px solid #fff; border-radius:12px; padding:14px; }
      h2,h3{ color:#fff; font-family:Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; }
      textarea,input{ width:100%; background:var(--dark-blue); color:#fff; border:2px solid #fff; border-radius:10px; padding:8px; font-family:monospace; }
      button{ background:#fff; color:var(--dark-blue); border:2px solid #fff; border-radius:10px; padding:8px 14px; font-weight:bold; cursor:pointer; }
      button:disabled{ opacity:.3; cursor:default; }
      .light { width: 18px; height: 18px; border-radius: 50%; border: 3px solid #fff; display:inline-block; vertical-align:middle; }
      .row { display:flex; gap:.75rem; align-items:center; flex-wrap:wrap; }
      .tight { margin-top:.35rem; }
      .muted { color:#aaa; font-size:14px; }
      .btn.block-lime{ background:#18ea4a; color:#000; }
      .btn.block-yellow{ background:#ffcc00; color:#000; }
      .code-card{ text-align:center; }
      .code-big{ font-size:64px; font-family:Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; margin:12px 0; color:#fff; }
      .status{ font-size:14px; color:#aaa; }
    </style>

    <h2>Key Room</h2>

    <section class="panel">
      <div class="row">
        <span class="light" id="light-api" data-state="red"></span>
        <input id="api" type="password" placeholder="API KEY">
        <button id="saveApi" class="btn">SAVE</button>
      </div>
      <p class="status tight">Stored locally only.</p>
    </section>

    <section class="panel">
      <div class="row"><span class="light" id="light-q" data-state="red"></span><h3>Questions</h3></div>
      <textarea id="q" rows="7"></textarea>
      <div class="row"><button id="saveQ" class="btn block-lime">SAVE</button><span class="muted">Save to Firestore for this CODE.</span></div>
    </section>

    <section class="panel">
      <div class="row"><span class="light" id="light-j" data-state="red"></span><h3>Jemima</h3></div>
      <textarea id="j" rows="7"></textarea>
      <div class="row"><button id="saveJ" class="btn block-lime">SAVE</button><span class="muted">Save to Firestore for this CODE.</span></div>
    </section>

    <section class="panel code-card" style="height:40vh;">
      <div>
        <div id="big" class="code-big">${getCode() || '—'}</div>
        <div class="row" style="justify-content:center; margin-top:10px;">
          <button id="get" class="btn block-yellow">CODE</button>
          <button id="seed" class="btn" disabled>SEED</button>
        </div>
        <p id="seedHelp" class="status"></p>
        <p id="status" class="status"></p>
      </div>
    </section>
  `;

  // ---------- Events ----------
  $('#saveApi').onclick = saveApi;
  $('#saveQ').onclick   = () => savePrompt('q');
  $('#saveJ').onclick   = () => savePrompt('j');
  $('#get').onclick     = createCode;
  $('#seed').onclick    = toSeeding;
  $('#q').addEventListener('input', () => light('#light-q','amber'));
  $('#j').addEventListener('input', () => light('#light-j','amber'));

  // init
  (async () => {
    if (LS.hasKey()) { $('#api').value='••••••••'; light('#light-api','green'); }
    const code = getCode();
    if (code) {
      const { hasQ, hasJ, q, j } = await readPromptsForCode(code);
      if (hasQ) { $('#q').value=q; light('#light-q','green'); }
      if (hasJ) { $('#j').value=j; light('#light-j','green'); }
    }
    updateSeedButton();
  })();

  return el;
}
