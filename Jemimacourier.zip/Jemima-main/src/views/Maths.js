// /src/views/Maths.js
import { initFirebase, ensureAuth, db, doc, getDoc, setDoc, onSnapshot, auth } from '../lib/firebase.js';

export default function Maths(){
  const el=document.createElement('section'); el.className='wrap';
  const $=(s)=>el.querySelector(s);

  const code=(localStorage.getItem('lastGameCode')||'').toUpperCase();
  const NAME=(r)=> r==='host'?'Daniel':'Jaime';

  let isHost=false, me='guest', opp='host', q1=null,q2=null,a1=null,a2=null;

  async function ctx(){
    const rs=await getDoc(doc(db,'rooms',code)); const d=rs.data()||{};
    isHost=!!auth.currentUser?.uid && auth.currentUser.uid === (d.meta?.hostUid||'');
    me=isHost?'host':'guest'; opp=isHost?'guest':'host';
    $('#who').textContent=`${isHost?'Host':'Guest'} (${NAME(me)})`;
  }
  async function load(){
    const s=await getDoc(doc(db,'rooms',code,'seed','jmaths_pack'));
    const spec=s.data()?.spec||{}; const qs=spec.questions||[]; const ans=spec.answers||[];
    q1=qs[0]||{prompt:'Q1'}; q2=qs[1]||{prompt:'Q2'}; a1=Number(ans[0]); a2=Number(ans[1]);
    $('#q1').textContent=q1.prompt; $('#q2').textContent=q2.prompt;
  }
  function ok(){ const v1=$('#a1').value, v2=$('#a2').value; return /^\-?\d+$/.test(v1)&&/^\-?\d+$/.test(v2); }

  async function submit(){
    if(!ok()) return;
    const v1=Number($('#a1').value), v2=Number($('#a2').value);
    const sc=(Number(v1===a1)+Number(v2===a2));
    await setDoc(doc(db,'rooms',code,'players',me), { mathsAnswers:{q1:v1,q2:v2}, mathsScore:sc }, { merge:true });
    if(isHost) await waitOpp();
  }
  function oppReady(d){ return typeof d?.mathsScore==='number'; }
  async function waitOpp(){
    const ref=doc(db,'rooms',code,'players',opp);
    try{ const s=await getDoc(ref); if(oppReady(s.data())) return flip(); }catch{}
    onSnapshot(ref, async (s)=>{ if(oppReady(s.data())) await flip(); });
  }
  async function flip(){ await setDoc(doc(db,'rooms',code), { state:'final' }, { merge:true }); }

  el.innerHTML=`
    <h2>Maths</h2>
    <p class="status">You are: <strong id="who">…</strong> · Room: <strong>${code}</strong></p>
    <section class="panel">
      <div class="qprompt"><strong>Q1.</strong> <span id="q1">…</span></div>
      <input id="a1" class="input-field" type="number" step="1" placeholder="0">
      <div class="qprompt" style="margin-top:10px;"><strong>Q2.</strong> <span id="q2">…</span></div>
      <input id="a2" class="input-field" type="number" step="1" placeholder="0">
      <div class="row" style="justify-content:flex-end; margin-top:10px;">
        <button id="done" class="btn block-yellow" disabled>DONE</button>
      </div>
    </section>
  `;
  (async()=>{ await initFirebase(); await ensureAuth(); await ctx(); await load();
    const v=()=>{ $('#done').disabled=!ok(); }; $('#a1').addEventListener('input',v); $('#a2').addEventListener('input',v);
    $('#done').onclick=submit;
  })();
  return el;
}
