// /src/views/Interlude.js
import { initFirebase, ensureAuth, db, doc, getDoc, setDoc, auth, onSnapshot } from '../lib/firebase.js';

export default function Interlude(){
  const el=document.createElement('section'); el.className='wrap';
  const $=(s)=>el.querySelector(s);

  const code=(localStorage.getItem('lastGameCode')||'').toUpperCase();
  const NAME=(r)=> r==='host'?'Daniel':'Jaime';

  let isHost=false, me='guest', opp='host', round=1, unsub=null;

  async function ctx(){
    const rs=await getDoc(doc(db,'rooms',code)); const d=rs.data()||{};
    isHost=!!auth.currentUser?.uid && auth.currentUser.uid === (d.meta?.hostUid||'');
    me=isHost?'host':'guest'; opp=isHost?'guest':'host';
    const m=String(d.state||'').match(/jclue_r(\d+)/); round=m?(parseInt(m[1],10)||1):1;
    $('#r').textContent=round; $('#who').textContent=`${isHost?'Host':'Guest'} (${NAME(me)})`;
  }

  async function load(){
    const s=await getDoc(doc(db,'rooms',code,'seed',`jclue_r${round}`));
    $('#clue').textContent = s.data()?.spec?.text || '…';
  }

  async function ready(){
    await setDoc(doc(db,'rooms',code,'players',me), { interludeReady:{[`r${round}`]:true} }, { merge:true });
    $('#wait').textContent=`Waiting for ${NAME(opp)}…`;
    if(!isHost) return;
    const ref=doc(db,'rooms',code,'players',opp);
    try{ const s=await getDoc(ref); if(s.data()?.interludeReady?.[`r${round}`]) return flip(); }catch{}
    unsub=onSnapshot(ref, async (snap)=>{ if(snap.data()?.interludeReady?.[`r${round}`]){ if(unsub){unsub();unsub=null;} await flip(); }});
  }
  async function flip(){ await setDoc(doc(db,'rooms',code), { state:`countdown_r${round+1}`, countdownT0: Date.now() }, { merge:true }); }

  el.innerHTML=`
    <h2>Interlude — R<span id="r">…</span></h2>
    <section class="panel"><p id="clue" style="font-size:22px; margin:0;"></p></section>
    <div class="row"><button id="next" class="btn block-yellow">NEXT</button><span id="wait" class="status"></span></div>
    <p class="status">You are: <strong id="who">…</strong> · Room: <strong>${code}</strong></p>
  `;
  (async()=>{ await initFirebase(); await ensureAuth(); await ctx(); await load(); $('#next').onclick=ready; })();
  el.$destroy=()=>{ if(unsub){ try{unsub();}catch{} } };
  return el;
}
