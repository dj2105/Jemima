// /src/views/Lobby.js
// Minimal infographic Lobby: Hi Mae, what's the code?
// Empty centered code box, bold Courier question, dark-blue theme.

import { initFirebase, ensureAuth, auth, db, doc, setDoc } from '../lib/firebase.js';

export default function Lobby(ctx = {}) {
  const el = document.createElement('section');

  // utils
  const $ = (s)=>el.querySelector(s);
  const LS = { set(k,v){ try{localStorage.setItem(k,v);}catch{} } };
  const ABC='ABCDEFGHJKLMNPQRSTUVWXYZ123456789';
  const sanitize=(raw)=>String(raw||'').toUpperCase().replace(/[^A-Z0-9]/g,'').split('').filter(c=>ABC.includes(c)).slice(0,3).join('');

  function canJoin(){ return ($('#code').value||'').length===3; }
  function updateArrow(){ $('#go').classList.toggle('on', canJoin()); }

  async function joinAsJaime(){
    const code = sanitize($('#code').value);
    if(code.length!==3) return;
    await initFirebase(); await ensureAuth();
    LS.set('playerRole','guest'); LS.set('lastGameCode',code);
    await setDoc(doc(db,'rooms',code), {
      meta:{ guestUid: auth.currentUser?.uid || 'guest' },
      state:'seeding', countdownT0: Date.now(), countdownSecs:3
    }, { merge:true });
    location.hash = '#/seeding';
  }
  function goKeyRoom(){ LS.set('playerRole','host'); location.hash = '#/keyroom'; }

  // view
  el.className = 'wrap';
  el.innerHTML = `
    <style>
      :root {
        --dark-blue: #020b1a;
      }
      body { background:#fff; color:var(--dark-blue); }
      .center-wrap{
        position: fixed; left: 50%; top: 50%;
        transform: translate(-50%, -50%);
        width: min(560px, 92vw);
        text-align: center;
      }
      .title{
        font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
        font-size: clamp(56px, 9vw, 108px);
        line-height: .85;
        margin: 0 0 18px 0;
        text-transform: uppercase;
        color: var(--dark-blue);
      }
      .title span{ display:block; }
      .courier{
        font-family: "Courier New", Courier, monospace;
        font-weight: bold;
        font-size: clamp(20px, 2.8vw, 28px);
        margin: 0 0 12px;
        color: var(--dark-blue);
      }
      .code-row{
        display: grid;
        grid-template-columns: auto 64px;
        gap: 10px;
        align-items: center;
        justify-content: center;
      }
      .code-input{
        width: clamp(180px, 26vw, 230px);
        text-align: center;
        font-family: "Courier New", Courier, monospace;
        font-size: clamp(42px, 7.2vw, 64px);
        padding: 10px 12px;
        background:#fff;
        color: var(--dark-blue);
        border: 6px solid var(--dark-blue);
        border-radius: 14px;
        outline: none;
        text-transform: uppercase;
      }
      .arrow{
        display:inline-flex; align-items:center; justify-content:center;
        width: 64px; height: 64px;
        border: 6px solid var(--dark-blue); border-radius: 14px;
        background: #e9e9e9; color:#a0a0a0;
        font-size: 36px; cursor: default;
        transition: background .15s, color .15s, box-shadow .15s;
      }
      .arrow.on{
        background: var(--dark-blue); color:#fff; cursor:pointer;
        animation: pulseGlow 1.4s ease-in-out infinite;
      }
      @keyframes pulseGlow{
        0%{ box-shadow:0 0 0 0 rgba(2,11,26,.6); }
        70%{ box-shadow:0 0 0 14px rgba(2,11,26,0); }
        100%{ box-shadow:0 0 0 0 rgba(2,11,26,0); }
      }
      .link{
        font-family: "Courier New", Courier, monospace;
        font-weight: bold;
        text-decoration: none;
        color: var(--dark-blue);
        border-bottom: 4px solid var(--dark-blue);
        padding: 2px 4px 0;
      }
      .link:hover{ background: var(--dark-blue); color:#fff; }
    </style>

    <div class="center-wrap">
      <h1 class="title"><span>JEMIMA’S</span><span>ASKING</span></h1>
      <p class="courier">Question one.</p>
      <p class="courier">Jaime: "what’s the code?"</p>
      <div class="code-row">
        <input id="code" class="code-input" maxlength="3"
          inputmode="latin-prose" autocomplete="off" autocapitalize="characters"
          spellcheck="false" />
        <button id="go" class="arrow" aria-disabled="true" title="Join">➔</button>
      </div>
      <a id="hostLink" class="link" href="javascript:void(0)">Daniel’s Entrance</a>
    </div>
  `;

  // behaviour
  $('#code').addEventListener('input', (e)=>{
    e.target.value = sanitize(e.target.value);
    updateArrow();
  });
  $('#code').addEventListener('keydown', (e)=>{
    if (e.key==='Enter' && canJoin()) joinAsJaime();
  });
  $('#go').addEventListener('click', ()=>{ if (canJoin()) joinAsJaime(); });
  $('#hostLink').addEventListener('click', goKeyRoom);

  updateArrow();
  return el;
}
