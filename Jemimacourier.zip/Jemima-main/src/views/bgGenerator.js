// /src/lib/bgGenerator.js
// Runs in the host's browser after Round 1 flips to countdown.
// Generates rounds 2–5 sequentially with extended repair attempts (no fallbacks).

import { db, doc, getDoc, setDoc, auth } from '../lib/firebase.js';
import { callGeminiQuestionsForRound } from '../gemini.js';

export async function startBackgroundQuestionGen({ code, apiKey, userPrompt, firstRoundDone = 1, repairRounds = 6, log = ()=>{} } = {}) {
  try {
    const roomSnap = await getDoc(doc(db,'rooms',code));
    const isHost = !!auth.currentUser?.uid && auth.currentUser.uid === (roomSnap.data()?.meta?.hostUid || '');
    if (!isHost) return; // Only the host should run background generation
  } catch { return; }

  for (let r = firstRoundDone + 1; r <= 5; r++) {
    try {
      const existing = await getDoc(doc(db,'rooms',code,'seed',`qpack_r${r}`));
      if (existing.exists()) { log(`R${r} already exists — skipping.`); continue; }

      log(`Generating R${r}…`);
      const res = await callGeminiQuestionsForRound(apiKey, userPrompt, r, { repairRounds });
      if (res.rejected?.length) {
        res.rejected.forEach(rr => log(`R${r} fix: Q${(rr.index||0)+1} — ${rr.reason}`));
      }
      await setDoc(doc(db,'rooms',code,'seed',`qpack_r${r}`), { spec:{ questions: res.json.questions } }, { merge:true });
      log(`✔ Saved R${r}`);
      await setDoc(doc(db,'rooms',code), { meta: { bgGen: `R${r} done` } }, { merge:true });
    } catch (e) {
      log(`⚠ R${r} failed: ${e?.message || e}`);
      await setDoc(doc(db,'rooms',code), { meta: { bgGen: `R${r} error` } }, { merge:true });
      // keep going to try later rounds anyway
    }
  }

  log('BG generation finished.');
  await setDoc(doc(db,'rooms',code), { meta: { bgGen: 'finished' } }, { merge:true });
}
