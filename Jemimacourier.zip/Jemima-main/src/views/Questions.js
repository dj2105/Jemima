// /src/views/Questions.js
import { initFirebase, ensureAuth, db, doc, getDoc, setDoc, onSnapshot, auth } from '../lib/firebase.js';

export default function Questions(){
  const el=document.createElement('section'); el.className='wrap';
  const $=(s)=>el.querySelector(s);

  const code=(localStorage.getItem('lastGameCode')||'').toUpperCase();
  const NAME=(r)=> r==='host'?'Daniel':'Jaime';

  let isHost=false, me='guest', opp='host', round=1, unsub=null;
  const answers=Object.create(null); let qs=[];

  function opts(q){
    const l=Array.isArray(q.options)?q.options:[];
    const a=l.find(o=>o?.key==='A')||l[0]||{key:'A',text:''};
    const b=l.find(o=>o?.key==='B')||l[1]||{key:'B',text:''};
    return [a,b];
  }

  async function ctx(){
    const rs=await getDoc(doc(db,'rooms',code)); const d=rs.data()||{};
    isHost = !!auth.currentUser?.uid && auth.currentUser.uid === (d.meta?.hostUid||'');
    me=isHost?'host':'guest'; opp=isHost?'guest':'host';
    const m=String(d.state||'').match(/questions_r(\d+)/); round=m?(parseInt(m[1],10)||1):1;
    $('#who').textContent=`${isHost?'Host':'Guest'} (${NAME(me)})`; $('#round').textContent=round;
  }

  async function load(){
    const base=doc(db,'rooms',code,'seed',`qpack_r${round}`),
          host=doc(db,'rooms',code,'seed',`qpack_r${round}_host`),
          guest=doc(db,'rooms',code,'seed',`qpack_r${round}_guest`);
    if(me==='host'){
      const h=await getDoc(host);
      if(h.exists()) qs=(h.data()?.spec?.questions||[]).slice(0,3);
      else { const b=await getDoc(base); qs=(b.data()?.spec?.questions||[]).slice(0,3); }
    } else {
      const g=await getDoc(guest);
      if(g.exists()) qs=(g.data()?.spec?.questions||[]).slice(0,3);
      else { const b=await getDoc(base); qs=(b.data()?.spec?.questions||[]).slice(3,6); }
    }
    if(qs.length!==3) throw new Error('Need 3 questions');
  }

  function render(){
    const list=$('#list'); list.innerHTML='';
    qs.forEach((q,i)=>{
      const id=q.id||`q${i+1}`; const [A,B]=opts(q);
      const row=document.createElement('div'); row.className='qrow'; row.dataset.qid=id;
      row.innerHTML=`
        <div class="qprompt"><strong>Q${i+1}.</strong> ${q.prompt||''}</div>
        <div class="row">
          <label class="radio"><input type="radio" name="n_${id}" value="A"><span>A</span></label>
          <label class="radio"><input type="radio" name="n_${id}" value="B"><span>B</span></label>
        </div>
        <div class="row" style="gap:.5rem; font-size:18px;">
          <div><strong>A</strong> — ${A.text}</div>
          <div><strong>B</strong> — ${B.text}</div>
        </div>
      `;
      list.appendChild(row);
    });
    list.querySelectorAll('input[type="radio"]').forEach(i=>{
      i.addEventListener('change',e=>{
        const r=e.currentTarget.closest('.qrow'); const id=r.dataset.qid;
        answers[id]=e.currentTarget.value; check();
      });
    });
    check();
  }

  function check(){
    const ok=qs.every((q,i)=> (answers[q.id||`q${i+1}`]==='A'||answers[q.id||`q${i+1}`]==='B'));
    $('#done').disabled=!ok;
    $('#count').textContent = `${Object.keys(answers).length} / 3`;
  }

  async function submit(){
    const rkey=`r${round}`; const map={};
    qs.forEach((q,i)=>{ const id=q.id||`q${i+1}`; map[id]=answers[id]; });
    await setDoc(doc(db,'rooms',code,'players',me), {
      answers:{ [rkey]:map }, timestamps:{ [`${rkey}Submitted`]: Date.now() }
    }, { merge:true });
    if(isHost) await waitOpp();
  }

  function oppSubmitted(d){
    const ts=(d?.timestamps||{})[`r${round}Submitted`];
    const a=(d?.answers||{})[`r${round}`];
    return (typeof ts==='number'&&ts>0) || (a && Object.keys(a).length>=3);
  }

  async function waitOpp(){
    $('#after').textContent=`Waiting for ${NAME(opp)}…`;
    const ref=doc(db,'rooms',code,'players',opp);
    try{ const s=await getDoc(ref); if(oppSubmitted(s.data())) return flip(); }catch{}
    unsub=onSnapshot(ref, async (s)=>{ if(!s.exists())return; if(oppSubmitted(s.data())){ if(unsub){unsub();unsub=null;} await flip(); }});
  }
  async function flip(){ await setDoc(doc(db,'rooms',code), { state:`marking_r${round}` }, { merge:true }); }

  el.innerHTML=`
    <h2>Questions — R<span id="round">…</span></h2>
    <p class="status">You are: <strong id="who">…</strong> · Room: <strong>${code}</strong></p>
    <section class="panel">
      <div id="list" class="q-list"></div>
      <div class="row" style="justify-content:space-between;">
        <span id="count" class="status">0 / 3</span>
        <button id="done" class="btn block-yellow" disabled>DONE</button>
      </div>
      <p id="after" class="status"></p>
    </section>
  `;
  (async()=>{ await initFirebase(); await ensureAuth(); await ctx(); await load(); render(); })();
  $('#done').onclick=submit;
  el.$destroy=()=>{ if(unsub){ try{unsub();}catch{} } };
  return el;
}
