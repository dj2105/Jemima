// /src/views/Countdown.js
import { initFirebase, ensureAuth, db, doc, getDoc, setDoc, auth } from '../lib/firebase.js';

export default function Countdown(){
  const el=document.createElement('section'); el.className='wrap';
  const $=(s)=>el.querySelector(s);

  const code=(localStorage.getItem('lastGameCode')||'').toUpperCase();
  let isHost=false, round=1, t0=null, tick=null;

  const SECS=3, TICK=80;

  function num(rem){ return rem<=0 ? 'GO' : String(Math.ceil(rem)); }

  async function read(){
    const rs=await getDoc(doc(db,'rooms',code));
    const d=rs.data()||{};
    isHost = !!auth.currentUser?.uid && auth.currentUser.uid === (d.meta?.hostUid||'');
    const m=String(d.state||'').match(/countdown_r(\d+)/); round=m?(parseInt(m[1],10)||1):1;
    t0=typeof d.countdownT0==='number'?d.countdownT0:null;
    $('#r').textContent=round;
  }

  async function flip(){ await setDoc(doc(db,'rooms',code), { state:`questions_r${round}` }, { merge:true }); }
  function start(){
    stop();
    tick=setInterval(async()=>{
      const rem = SECS - (Date.now()-t0)/1000;
      $('#num').textContent = num(rem);
      if(rem<=0){ stop(); if(isHost) await flip(); }
    }, TICK);
  }
  function stop(){ if(tick){ clearInterval(tick); tick=null; } }

  el.innerHTML=`
    <h2>Round <span id="r">…</span></h2>
    <section class="panel code-card" style="height:55vh;">
      <div id="num" class="countdown-number">3</div>
    </section>
  `;

  (async()=>{ await initFirebase(); await ensureAuth(); await read(); if(t0) start(); })();
  el.$destroy=stop; return el;
}
