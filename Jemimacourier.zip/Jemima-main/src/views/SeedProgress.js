// /src/views/SeedProgress.js
// Seeds just Round 1 (6 Qs). No fallbacks. Starts background generator for R2–R5.

import { initFirebase, ensureAuth, db, doc, getDoc, setDoc, onSnapshot, auth } from '../lib/firebase.js';
import { callGeminiQuestionsForRound, callGeminiInterludesAndMaths } from '../gemini.js';
import { startBackgroundQuestionGen } from '../lib/bgGenerator.js';

export default function SeedProgress(ctx = {}) {
  const el = document.createElement('section');
  el.className = 'panel wrap';
  const $ = (s) => el.querySelector(s);

  const ls = (k,d='') => { try { return localStorage.getItem(k) ?? d; } catch { return d; } };
  const code = (ls('lastGameCode','') || '').toUpperCase();

  function setStatus(msg){ const n=$('#status'); if(n) n.textContent = msg || ''; }
  function log(s){ const n=document.createElement('div'); n.textContent=String(s); $('#log').appendChild(n); }
  const maskKey = (k)=> !k ? '(none)' : (k.length<=8 ? k[0]+'…'+k[k.length-1] : k.slice(0,4)+'…'+k.slice(-4));

  const clamp = (s, max) => (typeof s === 'string' && s.length > max) ? (s.slice(0, max - 1).trimEnd() + '…') : String(s ?? '');
  const asAB = (x) => (x === 'A' || x === 'B') ? x : (x === 0 ? 'A' : x === 1 ? 'B' : null);
  function isLikelyJSON(str) { if (!str) return false; const t=str.trim(); if (!(t.startsWith('{')&&t.endsWith('}'))) return false; try{ JSON.parse(t); return true; }catch{ return false; } }

  function convertHostPack(jsonObj) {
    const quiz = jsonObj?.quiz;
    const roundsIn = Array.isArray(quiz?.rounds) ? quiz.rounds : [];
    if (roundsIn.length < 1) throw new Error(`Host pack must contain at least Round 1.`);
    const rnd = roundsIn[0];
    const rnum = Number(rnd?.round_number ?? 1);
    const qsIn = Array.isArray(rnd?.questions) ? rnd.questions : [];
    if (qsIn.length !== 6) throw new Error(`Round ${rnum} must contain exactly 6 questions; found ${qsIn.length}.`);
    const qs = qsIn.map((q,i)=>{
      const id=`r${rnum}q${i+1}`;
      const A=String(q?.options?.A ?? q?.options?.a ?? '');
      const B=String(q?.options?.B ?? q?.options?.b ?? '');
      const correct=asAB(q?.correct_answer ?? q?.correct ?? null);
      if(!A||!B||!correct) throw new Error(`Q${i+1} missing A/B/correct`);
      return { id, prompt: clamp(String(q?.prompt||''),140), options:[{key:'A',text:clamp(A,80)},{key:'B',text:clamp(B,80)}], correct };
    });
    return { round: rnum, questions: qs };
  }

  async function seedAsHost() {
    const apiKey = ls('gemini_api_key','');
    log(`API key present: ${apiKey ? 'yes' : 'no'} (${maskKey(apiKey)})`);

    const qcfgSnap = await getDoc(doc(db, 'rooms', code, 'seed', 'qcfg'));
    const jmsSnap  = await getDoc(doc(db, 'rooms', code, 'seed', 'jmaths'));
    const qPrompt = qcfgSnap.data()?.spec?.prompt ?? '';
    const jPrompt = jmsSnap.data()?.spec?.prompt ?? '';

    if (!qPrompt.trim()) throw new Error('Missing Questions prompt (seed/qcfg.spec.prompt). Go to Key Room and SAVE.');
    if (!jPrompt.trim()) throw new Error('Missing Jemima prompt (seed/jmaths.spec.prompt). Go to Key Room and SAVE.');

    // 1) ROUND 1 QUESTIONS (host JSON or Gemini for round 1 only)
    let r1;
    if (isLikelyJSON(qPrompt)) {
      log('Detected host JSON. Ingesting Round 1 only…');
      r1 = convertHostPack(JSON.parse(qPrompt.trim()));
    } else {
      if (!apiKey) throw new Error('No Gemini API key found.');
      log('Calling Gemini for Round 1 (strict JSON + verification, extended repairs)…');
      // Allow more repair attempts for R1, e.g. 5
      const res = await callGeminiQuestionsForRound(apiKey, qPrompt, 1, { repairRounds: 5 });
      if (res.rejected?.length) {
        log('✳ Repaired (replaced) in R1:');
        res.rejected.forEach(r => log(`R${r.round}Q${(r.index||0)+1} — ${r.reason}: ${r.prompt}`));
      }
      r1 = res.json; // { round, questions }
    }

    await setDoc(doc(db, 'rooms', code, 'seed', 'qpack_r1'), { spec: { questions: r1.questions } }, { merge: true });
    log('✔ Saved R1 questions');

    // 2) INTERLUDES + MATHS (we’ll have these ready)
    if (!apiKey) throw new Error('No Gemini API key found for interludes + maths.');
    log('Calling Gemini for interludes + maths…');
    const jmRes = await callGeminiInterludesAndMaths(apiKey, jPrompt);
    const inter = Array.isArray(jmRes?.json?.interludes) ? jmRes.json.interludes : [];
    const mathsQ = jmRes?.json?.maths?.questions || [];
    const mathsA = jmRes?.json?.maths?.answers || [];
    if (inter.length < 4) throw new Error('Gemini returned fewer than 4 interludes.');
    if (mathsQ.length !== 2 || mathsA.length !== 2) throw new Error('Gemini maths must contain exactly 2 questions and 2 answers.');

    for (let r = 1; r <= 4; r++) {
      await setDoc(doc(db, 'rooms', code, 'seed', `jclue_r${r}`), { spec: { text: String(inter[r-1] || '') } }, { merge: true });
    }
    log('✔ Saved interludes');
    await setDoc(doc(db, 'rooms', code, 'seed', 'jmaths_pack'), {
      spec: {
        questions: mathsQ.map(q => ({ prompt: String(q?.prompt ?? q), type: 'number' })),
        answers: mathsA.map(n => Number(n))
      }
    }, { merge: true });
    log('✔ Saved maths pack');

    // 3) FLIP TO COUNTDOWN, THEN START BACKGROUND GENERATION (R2–R5)
    await setDoc(doc(db, 'rooms', code), {
      state: 'countdown_r1',
      countdownT0: Date.now(),
      countdownSecs: 3,
      meta: { ...( (await getDoc(doc(db,'rooms',code))).data()?.meta || {} ), bgGen: 'starting' }
    }, { merge: true });
    setStatus('Round 1 ready — starting…');

    // Kick off background generator on the host (no blocking!)
    startBackgroundQuestionGen({
      code,
      apiKey,
      userPrompt: qPrompt,
      firstRoundDone: 1,
      repairRounds: 6,     // allow more attempts in background
      log: (m)=>log('BG: '+m)
    });
  }

  async function run() {
    await initFirebase(); await ensureAuth();
    setStatus(`Room ${code} — preparing…`);

    const rs = await getDoc(doc(db, 'rooms', code));
    if (!rs.exists()) { setStatus('Room not found.'); return; }
    const data = rs.data() || {};
    const isHost = !!auth.currentUser?.uid && auth.currentUser.uid === (data.meta?.hostUid || '');

    if (!isHost) {
      $('#hostOnly').style.display = 'none';
      setStatus('Waiting for host…');
      onSnapshot(doc(db, 'rooms', code), (snap) => {
        const st = String(snap.data()?.state || '');
        if (st.startsWith('countdown_r')) location.hash = '#/countdown';
      });
      return;
    }

    $('#guestOnly').style.display = 'none';
    try {
      log('Host detected. Starting seeding…');
      await seedAsHost();
    } catch (e) {
      const msg = (e?.message || e).toString();
      setStatus('❌ ' + msg);
      log('------ DEBUG DETAILS ------');
      log(msg);
      log('---------------------------');
    }
  }

  el.innerHTML = `
    <h2>Seeding</h2>
    <p class="status">Prepping Round 1; others will generate while you play.</p>

    <section class="panel">
      <div id="hostOnly">
        <div id="log" style="min-height:6lh; white-space:pre-wrap;"></div>
      </div>
      <div id="guestOnly">
        <p class="status">Host is preparing Round 1… you’ll move on automatically.</p>
      </div>
      <p id="status" class="status" style="margin-top:.5rem; white-space:pre-wrap;"></p>
    </section>
  `;

  (async () => { try { await run(); } catch (e) { setStatus('❌ ' + (e?.message || e)); } })();

  return el;
}
