// /src/views/Award.js
import { initFirebase, ensureAuth, db, doc, getDoc, setDoc, auth, onSnapshot } from '../lib/firebase.js';

export default function Award(){
  const el=document.createElement('section'); el.className='wrap';
  const $=(s)=>el.querySelector(s);

  const code=(localStorage.getItem('lastGameCode')||'').toUpperCase();
  const NAME=(r)=> r==='host'?'Daniel':'Jaime';

  let isHost=false, me='guest', opp='host', round=1, timer=null;

  async function ctx(){
    const rs=await getDoc(doc(db,'rooms',code)); const d=rs.data()||{};
    isHost=!!auth.currentUser?.uid && auth.currentUser.uid === (d.meta?.hostUid||'');
    me=isHost?'host':'guest'; opp=isHost?'guest':'host';
    const m=String(d.state||'').match(/award_r(\d+)/); round=m?(parseInt(m[1],10)||1):1;
    $('#r').textContent=round;
  }

  async function show(){
    const os=await getDoc(doc(db,'rooms',code,'players',opp));
    const gave=(os.data()?.awardsGiven||{})[`r${round}`];
    $('#big').textContent = `${NAME(opp)} → ${typeof gave==='number'?gave:'…'} / 3`;
  }

  async function next(){
    if(!isHost) return;
    timer=setTimeout(async()=>{
      const nxt = (round<4) ? `jclue_r${round}` : (round<5? `countdown_r${round+1}` : 'maths_questions');
      await setDoc(doc(db,'rooms',code), { state:nxt, countdownT0: Date.now() }, { merge:true });
    }, 3000);
  }

  el.innerHTML=`
    <h2>Award — R<span id="r">…</span></h2>
    <section class="panel code-card" style="height:55vh;">
      <div id="big" class="countdown-number">…</div>
    </section>
  `;
  (async()=>{ await initFirebase(); await ensureAuth(); await ctx(); await show(); await next();
    onSnapshot(doc(db,'rooms',code,'players',opp),(s)=>{ const v=(s.data()?.awardsGiven||{})[`r${round}`]; if(typeof v==='number') $('#big').textContent = \`\${NAME(opp)} → \${v} / 3\`; });
  })();
  el.$destroy=()=>{ if(timer) try{clearTimeout(timer);}catch{} };
  return el;
}
