// /src/views/SeedProgress.js
// Host-only Gemini seeding with safe fallbacks. Guest just waits & follows.

import {
  initFirebase, ensureAuth, db, doc, getDoc, setDoc, onSnapshot, auth
} from '../lib/firebase.js';
import { callGeminiQuestions, callGeminiInterludesAndMaths } from '../gemini.js';

export default function SeedProgress(ctx = {}) {
  const el = document.createElement('section');
  el.className = 'panel wrap';
  const $ = (s) => el.querySelector(s);

  const ls = (k,d='') => { try { return localStorage.getItem(k) ?? d; } catch { return d; } };
  const code = (ls('lastGameCode','') || '').toUpperCase();

  function setStatus(msg){ const n=$('#status'); if(n) n.textContent = msg || ''; }
  function log(s){ const n=document.createElement('div'); n.textContent=String(s); $('#log').appendChild(n); }
  const maskKey = (k)=> !k ? '(none)' : (k.length<=8 ? k[0]+'…'+k[k.length-1] : k.slice(0,4)+'…'+k.slice(-4));

  async function getPrompt(docId) {
    const snap = await getDoc(doc(db,'rooms',code,'seed',docId));
    return String(snap.data()?.spec?.prompt || '');
  }

  async function maybeBackfillFromLocal(docId, localKey) {
    const fsText = await getPrompt(docId);
    if (fsText.trim()) return fsText;
    const localText = (ls(localKey) || '').trim();
    if (localText) {
      log(`No ${docId} in Firestore — backfilling from localStorage[${localKey}] (${localText.length} chars)…`);
      await setDoc(doc(db,'rooms',code,'seed',docId), { spec: { prompt: localText } }, { merge:true });
      return localText;
    }
    return '';
  }

  async function seedAsHost() {
    const apiKey = ls('gemini_api_key','');
    log(`API key present: ${apiKey ? 'yes' : 'no'} (${maskKey(apiKey)})`);
    if (!apiKey) throw new Error('No Gemini API key found — paste it in Key Room and click “Save Key (local)”.');

    // Pull prompts; if missing in Firestore, copy from localStorage automatically
    let qPrompt = await maybeBackfillFromLocal('qcfg','qcfgPrompt');
    let jPrompt = await maybeBackfillFromLocal('jmaths','jmathsPrompt');

    log(`Questions prompt length: ${qPrompt.length} chars`);
    log(`Jemima prompt length: ${jPrompt.length} chars`);

    if (!qPrompt.trim()) throw new Error('Missing Questions prompt. Go to Key Room, paste questions.txt, click “Save to Firestore”.');
    if (!jPrompt.trim()) throw new Error('Missing Jemima maths prompt. Go to Key Room, paste Jemima.txt, click “Save to Firestore”.');

    // --- Questions ---
    log('Calling Gemini for 5 rounds of questions…');
    let qCall;
    try {
      qCall = await callGeminiQuestions(apiKey, qPrompt);
    } catch (e) {
      const rawPreview = (e.rawText || JSON.stringify(e.raw || e.httpBody || {}, null, 2) || '').toString().slice(0,1200);
      throw new Error(`Questions generation failed (${e.stage || 'error'}): ${e.message}\n\nRaw preview:\n${rawPreview}`);
    }
    const qData = qCall.json;
    const qRawPreview = (qCall.rawText || '').slice(0,600);
    log('Questions raw preview (first 600 chars):'); log(qRawPreview);

    if (!Array.isArray(qData?.rounds) || qData.rounds.length < 5) {
      throw new Error('Gemini did not return 5 rounds.\nRaw preview:\n' + qRawPreview);
    }
    for (let r=1; r<=5; r++){
      const pack = qData.rounds.find(x => Number(x.round)===r);
      if (!pack || !Array.isArray(pack.questions) || pack.questions.length < 6) {
        throw new Error(`Round ${r} missing or has <6 questions.\nRaw preview:\n${qRawPreview}`);
      }
      await setDoc(doc(db,'rooms',code,'seed',`qpack_r${r}`), { spec:{ questions: pack.questions.slice(0,6) } }, { merge:true });
      log(`✔ Saved R${r} questions`);
    }

    // --- Interludes + Maths ---
    log('Calling Gemini for 4 interludes and 2 maths questions…');
    let jmCall;
    try {
      jmCall = await callGeminiInterludesAndMaths(apiKey, jPrompt);
    } catch (e) {
      const rawPreview = (e.rawText || JSON.stringify(e.raw || e.httpBody || {}, null, 2) || '').toString().slice(0,1200);
      throw new Error(`Interludes/Maths generation failed (${e.stage || 'error'}): ${e.message}\n\nRaw preview:\n${rawPreview}`);
    }
    const jm = jmCall.json;
    const jmRawPreview = (jmCall.rawText || '').slice(0,600);
    log('Interludes/Maths raw preview (first 600 chars):'); log(jmRawPreview);

    if (!Array.isArray(jm?.interludes) || jm.interludes.length < 4) {
      throw new Error('Gemini did not return 4 interludes.\nRaw preview:\n' + jmRawPreview);
    }
    for (let r=1; r<=4; r++){
      await setDoc(doc(db,'rooms',code,'seed',`jclue_r${r}`), { spec:{ text: String(jm.interludes[r-1]||'') } }, { merge:true });
    }
    log('✔ Saved interludes');

    const mq = jm?.maths?.questions || [];
    const ma = jm?.maths?.answers  || [];
    if (mq.length < 2 || ma.length < 2) {
      throw new Error('Gemini maths pack incomplete (need 2 questions + 2 answers).\nRaw preview:\n' + jmRawPreview);
    }
    await setDoc(doc(db,'rooms',code,'seed','jmaths_pack'), {
      spec:{
        questions: mq.slice(0,2).map(q => ({ prompt: String(q.prompt||''), type:'number' })),
        answers: ma.slice(0,2).map(n => Number(n))
      }
    }, { merge:true });
    log('✔ Saved maths pack');

    await setDoc(doc(db,'rooms',code), {
      state:'countdown_r1',
      countdownT0: Date.now(),
      countdownSecs:3
    }, { merge:true });

    setStatus('Seeding complete — starting Round 1…');
  }

  async function run(){
    await initFirebase(); await ensureAuth();
    setStatus(`Room ${code} — preparing…`);

    const rs = await getDoc(doc(db,'rooms',code));
    if (!rs.exists()) { setStatus('Room not found.'); return; }
    const data = rs.data()||{};
    const isHost = !!auth.currentUser?.uid && auth.currentUser.uid === (data.meta?.hostUid || '');

    if (!isHost) {
      // Guest: just wait & follow
      $('#hostOnly').style.display='none';
      setStatus('Waiting for host to prepare questions…');
      onSnapshot(doc(db,'rooms',code),(snap)=>{
        const st=String(snap.data()?.state||'');
        if (st.startsWith('countdown_r')) location.hash='#/countdown';
      });
      return;
    }

    $('#guestOnly').style.display='none';
    try {
      log('Host detected. Starting Gemini seeding…');
      await seedAsHost();
    } catch(e) {
      const msg=(e?.message||e).toString();
      setStatus('❌ ' + msg);
      log('------ DEBUG DETAILS ------'); log(msg); log('---------------------------');
    }
  }

  el.innerHTML = `
    <h2>Seeding</h2>
    <p class="status">Contacting Gemini and preparing the game. This takes a few seconds.</p>

    <section class="panel">
      <div id="hostOnly">
        <div id="log" style="min-height:6lh; white-space:pre-wrap;"></div>
      </div>
      <div id="guestOnly">
        <p class="status">Host is preparing content… you’ll move on automatically.</p>
      </div>
      <p id="status" class="status" style="margin-top:.5rem; white-space:pre-wrap;"></p>
    </section>
  `;

  (async ()=>{ try{ await run(); } catch(e){ setStatus('❌ '+(e?.message||e)); } })();

  return el;
}
