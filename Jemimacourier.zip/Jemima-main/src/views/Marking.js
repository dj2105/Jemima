// /src/views/Marking.js
import { initFirebase, ensureAuth, db, doc, getDoc, setDoc, onSnapshot, auth } from '../lib/firebase.js';

export default function Marking(){
  const el=document.createElement('section'); el.className='wrap';
  const $=(s)=>el.querySelector(s);

  const code=(localStorage.getItem('lastGameCode')||'').toUpperCase();
  const NAME=(r)=> r==='host'?'Daniel':'Jaime';

  let isHost=false, me='guest', opp='host', round=1, unsub=null;

  function set(m){ const n=$('#status'); if(n) n.textContent=m||''; }

  async function ctx(){
    const rs=await getDoc(doc(db,'rooms',code)); const d=rs.data()||{};
    isHost=!!auth.currentUser?.uid && auth.currentUser.uid === (d.meta?.hostUid||'');
    me=isHost?'host':'guest'; opp=isHost?'guest':'host';
    const m=String(d.state||'').match(/marking_r(\d+)/); round=m?(parseInt(m[1],10)||1):1;
    $('#who').textContent=`${isHost?'Host':'Guest'} (${NAME(me)})`; $('#round').textContent=round;
  }

  async function load(){
    const oppRef=doc(db,'rooms',code,'players',opp);
    const os=await getDoc(oppRef); const od=os.data()||{};
    const oppAns=((od.answers||{})[`r${round}`])||{};

    const roleDocId=`qpack_r${round}_${opp}`, baseDocId=`qpack_r${round}`;
    let ps=await getDoc(doc(db,'rooms',code,'seed',roleDocId));
    if(!ps.exists()) ps=await getDoc(doc(db,'rooms',code,'seed',baseDocId));
    const all=(ps.data()?.spec?.questions||[]);
    const list=(opp==='host')? all.slice(0,3) : all.slice(3,6);
    return { list, oppAns };
  }

  function render({list,oppAns}){
    const wrap=$('#list'); wrap.innerHTML='';
    list.forEach((q,i)=>{
      const id=q.id||`q${i+1}`;
      const opts=Array.isArray(q.options)?q.options:[];
      const chosen=opts.find(o=>o.key===oppAns[id]);
      const chosenTxt = chosen ? `${chosen.key}. ${chosen.text}` : '(no answer)';

      const row=document.createElement('div'); row.className='qrow'; row.dataset.qid=id;
      row.innerHTML=`
        <div class="qprompt"><strong>Q${i+1}.</strong> ${q.prompt||''}</div>
        <p class="status">${NAME(opp)} picked <strong>${chosenTxt}</strong></p>
        <div class="row">
          <button class="btn block-lime yes">YES</button>
          <button class="btn block-pink no">NO</button>
          <span class="status choice"></span>
        </div>
      `;
      wrap.appendChild(row);
    });

    wrap.querySelectorAll('.qrow').forEach(r=>{
      const out=r.querySelector('.choice');
      r.querySelector('.yes').onclick=()=>{ r.dataset.mark='correct'; out.textContent='✓'; check(); };
      r.querySelector('.no').onclick =()=>{ r.dataset.mark='incorrect'; out.textContent='✗'; check(); };
    });

    check();
  }

  function check(){
    const rows=[...$('#list').querySelectorAll('.qrow')];
    const ok=rows.every(r=>r.dataset.mark==='correct'||r.dataset.mark==='incorrect');
    $('#done').disabled=!ok;
  }

  async function submit(){
    $('#done').disabled=true;
    const rows=[...$('#list').querySelectorAll('.qrow')];
    const rkey=`r${round}`; const marks={}; let score=0;
    rows.forEach(r=>{
      const id=r.dataset.qid; const mk=r.dataset.mark==='correct'?'correct':'incorrect';
      marks[id]=mk; if(mk==='correct') score++;
    });
    await setDoc(doc(db,'rooms',code,'players',me), { marks:{[rkey]:marks}, awardsGiven:{[rkey]:score} }, { merge:true });
    if(isHost) await waitOpp();
  }

  function oppDone(d){
    const rkey=`r${round}`; const m=(d?.marks||{})[rkey]; const a=(d?.awardsGiven||{})[rkey];
    return m && Object.keys(m).length>=3 && typeof a==='number';
  }

  async function waitOpp(){
    $('#after').textContent=`Waiting for ${NAME(opp)}…`;
    const ref=doc(db,'rooms',code,'players',opp);
    try{ const s=await getDoc(ref); if(oppDone(s.data())) return flip(); }catch{}
    unsub=onSnapshot(ref, async (s)=>{ if(!s.exists())return; if(oppDone(s.data())){ if(unsub){unsub();unsub=null;} await flip(); }});
  }
  async function flip(){ await setDoc(doc(db,'rooms',code), { state:`award_r${round}` }, { merge:true }); }

  el.innerHTML=`
    <h2>Marking — R<span id="round">…</span></h2>
    <p class="status">You are: <strong id="who">…</strong> · Room: <strong>${code}</strong></p>
    <section class="panel">
      <div id="list" class="q-list"></div>
      <div class="row" style="justify-content:space-between;">
        <span id="status" class="status"></span>
        <button id="done" class="btn block-yellow" disabled>DONE</button>
      </div>
      <p id="after" class="status"></p>
    </section>
  `;
  (async()=>{ await initFirebase(); await ensureAuth(); await ctx(); const d=await load(); render(d); })();
  $('#done').onclick=submit;
  el.$destroy=()=>{ if(unsub){ try{unsub();}catch{} } };
  return el;
}
